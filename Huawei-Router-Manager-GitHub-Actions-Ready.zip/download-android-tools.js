const https = require('https');
const http = require('http');
const fs = require('fs');
const { URL } = require('url');

function download(urlStr, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const get = (url) => {
      const u = new URL(url);
      const client = u.protocol === 'https:' ? https : http;
      client.get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return get(res.headers.location);
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
        }

        const totalBytes = parseInt(res.headers['content-length'] || 0, 10);
        let downloadedBytes = 0;
        let lastReport = Date.now();

        res.on('data', (chunk) => {
          downloadedBytes += chunk.length;
          if (Date.now() - lastReport > 2000) {
            const mb = (downloadedBytes / (1024 * 1024)).toFixed(1);
            const totalMb = totalBytes ? (totalBytes / (1024 * 1024)).toFixed(1) + ' MB' : 'unknown';
            console.log(`Downloaded ${mb} MB / ${totalMb}`);
            lastReport = Date.now();
          }
        });

        res.pipe(file);
        file.on('finish', () => {
          file.close(() => {
            console.log(`✅ Finished downloading: ${destPath} (${(downloadedBytes / (1024*1024)).toFixed(1)} MB)`);
            resolve();
          });
        });
      }).on('error', (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
    };
    get(urlStr);
  });
}

const targetUrl = 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip';
const outPath = 'C:\\Users\\Wikum\\Desktop\\cmdline-tools.zip';

console.log('Downloading Google Android command-line tools...');
download(targetUrl, outPath).catch(err => {
  console.error('Download error:', err);
  process.exit(1);
});
