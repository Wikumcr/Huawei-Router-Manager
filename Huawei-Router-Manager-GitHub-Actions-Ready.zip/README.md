# Huawei Router Manager – Android

Android WebView app for the Huawei Router Manager interface.

## One-click APK build with GitHub Actions

1. Create a new GitHub repository.
2. Upload/extract **all files in this project** into the repository root (the folder containing `settings.gradle` and `gradlew`).
3. Commit and push to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and click **Run workflow** if it did not start automatically.
6. Open the completed workflow run.
7. Under **Artifacts**, download **Huawei-Router-Manager-debug-apk**.
8. Extract the downloaded artifact ZIP and install `app-debug.apk` on the Android phone.

The workflow uses GitHub's Ubuntu runner, JDK 17, the Gradle wrapper included in this project, and uploads the generated debug APK automatically.

## Local build

```bash
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Notes

- The app targets Android API 34 and requires Android 7.0 (API 24) or newer.
- The router web UI is bundled in `app/src/main/assets/www/`.
- The default Huawei router address used by the web app is `192.168.8.1`.
