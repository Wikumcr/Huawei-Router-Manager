-keepclassmembers class com.huawei.routermanager.WebAppInterface {
   public *;
}
