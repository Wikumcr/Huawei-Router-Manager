package com.huawei.routermanager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private WebView mWebView;
    private SwipeRefreshLayout mSwipeRefresh;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSwipeRefresh = findViewById(R.id.swipeRefreshLayout);
        mWebView = findViewById(R.id.webView);

        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(false);

        mWebView.addJavascriptInterface(new WebAppInterface(this), "Android");

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                mSwipeRefresh.setRefreshing(false);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                mSwipeRefresh.setRefreshing(false);
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient());

        mSwipeRefresh.setOnRefreshListener(() -> {
            mWebView.evaluateJavascript("if (typeof fetchDashboardData === 'function') fetchDashboardData();", value -> {
                mSwipeRefresh.setRefreshing(false);
            });
        });

        mSwipeRefresh.setColorSchemeResources(
            R.color.colorPrimary,
            R.color.colorAccent
        );

        // Load local asset web application
        mWebView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        // Evaluate if any open modal in webview should be closed first
        mWebView.evaluateJavascript(
            "(function() { " +
            "  var modals = document.querySelectorAll('.modal-overlay:not(.hidden)'); " +
            "  if (modals.length > 0) { " +
            "    modals.forEach(function(m) { m.classList.add('hidden'); }); " +
            "    return true; " +
            "  } " +
            "  return false; " +
            "})()",
            value -> {
                if ("true".equals(value)) {
                    // Modal was closed, do nothing further
                } else if (mWebView.canGoBack()) {
                    mWebView.goBack();
                } else {
                    super.onBackPressed();
                }
            }
        );
    }
}
