/**
 * Huawei Router Manager - Mobile Client Engine
 */

class MobileHiLinkClient {
  constructor(baseUrl = 'http://192.168.8.1') {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.sessionCookie = null;
    this.requestToken = null;
    this.inMemoryCredentials = { username: 'admin', password: '' };
    this.isLoggedIn = false;
    this.isMockMode = false;
    this.mockState = this.initMockState();
  }

  setMockMode(enable) {
    this.isMockMode = Boolean(enable);
  }

  setBaseUrl(url) {
    this.baseUrl = url.replace(/\/+$/, '');
    this.sessionCookie = null;
    this.requestToken = null;
  }

  parseXml(xmlString) {
    if (!xmlString || typeof xmlString !== 'string') return {};
    
    const errorMatch = xmlString.match(/<error>\s*<code>(.*?)<\/code>\s*(?:<message>(.*?)<\/message>)?\s*<\/error>/is);
    if (errorMatch) {
      const code = parseInt(errorMatch[1], 10) || errorMatch[1];
      const err = new Error(this.getErrorMessage(code));
      err.code = code;
      throw err;
    }

    const extractTags = (content) => {
      const result = {};
      const tagRegex = /<([a-zA-Z0-9_\-]+)>([\s\S]*?)<\/\1>|<([a-zA-Z0-9_\-]+)\s*\/>/g;
      let match, hasTags = false;

      while ((match = tagRegex.exec(content)) !== null) {
        hasTags = true;
        const tagName = match[1] || match[3];
        const innerContent = match[2] !== undefined ? match[2] : '';

        if (/<([a-zA-Z0-9_\-]+)>[\s\S]*?<\/\1>/i.test(innerContent)) {
          if (tagName.toLowerCase() === 'messages') {
            const messages = [];
            const msgRegex = /<Message>([\s\S]*?)<\/Message>/g;
            let m;
            while ((m = msgRegex.exec(innerContent)) !== null) {
              messages.push(extractTags(m[1]));
            }
            result[tagName] = messages;
          } else {
            result[tagName] = extractTags(innerContent);
          }
        } else {
          result[tagName] = innerContent
            .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&apos;/g, "'").trim();
        }
      }
      return hasTags ? result : content.trim();
    };

    const cleanXml = xmlString.replace(/<\?xml.*?\?>/gi, '').trim();
    const resMatch = cleanXml.match(/<response>([\s\S]*?)<\/response>/i);
    const target = resMatch ? resMatch[1] : cleanXml;

    if (target === 'OK' || target === '1') return { response: 'OK' };
    const parsed = extractTags(target);
    return typeof parsed === 'object' ? parsed : { value: parsed };
  }

  buildXml(data) {
    let xml = '<?xml version="1.0" encoding="UTF-8"?><request>';
    for (const [k, v] of Object.entries(data)) {
      if (Array.isArray(v)) {
        xml += `<${k}>`;
        for (const item of v) {
          xml += `<Phone>${this.escapeXml(item)}</Phone>`;
        }
        xml += `</${k}>`;
      } else {
        xml += `<${k}>${this.escapeXml(v)}</${k}>`;
      }
    }
    xml += '</request>';
    return xml;
  }

  escapeXml(unsafe) {
    if (!unsafe) return '';
    return String(unsafe).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  getErrorMessage(code) {
    const errorCodes = {
      100001: 'Internal router error (Code 100001)',
      100002: 'Feature not supported by router firmware (Code 100002)',
      100003: 'Router authentication required (Code 100003)',
      100004: 'Incorrect router admin password (Code 100004)',
      108002: 'Invalid password or expired session (Code 108002)',
      110001: 'SIM / SMS storage is full (Code 110001)',
      113017: 'Failed to send SMS message (Code 113017)'
    };
    return errorCodes[code] || `Router Error Code: ${code}`;
  }

  async request(endpoint, options = {}) {
    if (this.isMockMode) return this.handleMock(endpoint, options);

    const { method = 'GET', data = null, headers = {} } = options;
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;

    const reqHeaders = {
      'Accept': '*/*',
      'X-Requested-With': 'XMLHttpRequest',
      ...headers
    };

    if (this.requestToken) {
      reqHeaders['__RequestVerificationToken'] = this.requestToken;
    }

    let body = undefined;
    if (method === 'POST') {
      reqHeaders['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
      body = typeof data === 'string' ? data : (data ? this.buildXml(data) : undefined);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    try {
      const response = await fetch(url, {
        method,
        headers: reqHeaders,
        body,
        signal: controller.signal,
        credentials: 'omit'
      });
      clearTimeout(timeoutId);

      const rotatedToken = response.headers.get('__requestverificationtoken');
      if (rotatedToken) this.requestToken = rotatedToken;

      const text = await response.text();
      return this.parseXml(text);
    } catch (err) {
      clearTimeout(timeoutId);
      const isUnreachable = err.name === 'AbortError' || err.message.includes('Failed to fetch');
      const customErr = new Error(isUnreachable ? `Router at ${this.baseUrl} unreachable.` : err.message);
      customErr.isUnreachable = isUnreachable;
      throw customErr;
    }
  }

  async refreshTokens() {
    try {
      const res = await this.request('/api/webserver/SesTokInfo');
      if (res.TokInfo) this.requestToken = res.TokInfo;
      return res;
    } catch (e) {
      try {
        const res2 = await this.request('/api/webserver/token');
        if (res2.token) this.requestToken = res2.token;
        return res2;
      } catch (err) { return null; }
    }
  }

  async sha256(message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  async login(password, username = 'admin') {
    if (this.isMockMode) {
      this.isLoggedIn = true;
      return { success: true };
    }
    await this.refreshTokens();

    const p1Hex = await this.sha256(password);
    const p1Base64 = btoa(p1Hex);

    let hashedPass;
    if (this.requestToken) {
      const saltedHex = await this.sha256(username + p1Base64 + this.requestToken);
      hashedPass = btoa(saltedHex);
    } else {
      hashedPass = p1Base64;
    }

    const payload = { Username: username, Password: hashedPass, password_type: '4' };
    const res = await this.request('/api/user/login', { method: 'POST', data: payload });
    this.isLoggedIn = true;
    return { success: true, response: res };
  }

  async getStatus() {
    const d = await this.request('/api/monitoring/status');
    const connStatus = parseInt(d.ConnectionStatus, 10);
    const signalBars = Math.min(Math.max(parseInt(d.SignalIcon, 10) || 0, 0), 5);
    const netType = parseInt(d.CurrentNetworkType, 10) || 0;
    const netTypeEx = parseInt(d.CurrentNetworkTypeEx, 10) || 0;
    const uploadRate = parseInt(d.CurrentUploadRate, 10) || 0;
    const downloadRate = parseInt(d.CurrentDownloadRate, 10) || 0;

    return {
      connectionStatus: this.mapConnectionStatus(connStatus),
      signalBars,
      networkType: this.mapNetworkType(netType, netTypeEx),
      currentUploadFormatted: this.formatSpeed(uploadRate),
      currentDownloadFormatted: this.formatSpeed(downloadRate),
      totalUpload: parseInt(d.TotalUpload, 10) || 0,
      totalDownload: parseInt(d.TotalDownload, 10) || 0,
      batteryPercent: d.BatteryPercent !== undefined ? parseInt(d.BatteryPercent, 10) : null,
      batteryStatus: parseInt(d.BatteryStatus, 10) || 0,
      wifiUsers: parseInt(d.TotalWifiUser, 10) || 0,
      primaryDns: d.PrimaryDns || 'Auto'
    };
  }

  async getPlmn() {
    try {
      const d = await this.request('/api/net/current-plmn');
      return { fullName: d.FullName || d.ShortName || 'Mobile Network' };
    } catch (e) {
      return { fullName: 'Mobile Network' };
    }
  }

  async getSignalPara() {
    try {
      const d = await this.request('/api/device/signal');
      return { rsrp: d.rsrp || '', sinr: d.sinr || '' };
    } catch (e) {
      return { rsrp: '', sinr: '' };
    }
  }

  async getDeviceInfo() {
    try {
      const d = await this.request('/api/device/information');
      return {
        deviceName: d.DeviceName || 'Huawei E5573Cs-609',
        hardwareVersion: d.HardwareVersion || 'CL2E5573CSM',
        softwareVersion: d.SoftwareVersion || '21.328.01.00.00',
        webUiVersion: d.WebUIVersion || '17.100.11.00.03',
        imei: d.Imei || '',
        macAddress1: d.MacAddress1 || ''
      };
    } catch (e) {
      return { deviceName: 'Huawei E5573Cs-609', hardwareVersion: 'CL2E5573CSM', softwareVersion: 'Unknown', webUiVersion: 'Unknown' };
    }
  }

  async getSmsCount() {
    try {
      const d = await this.request('/api/sms/sms-count');
      return {
        unread: parseInt(d.LocalUnread, 10) || 0,
        inbox: parseInt(d.LocalInbox, 10) || 0,
        maxCount: parseInt(d.LocalMax, 10) || 500
      };
    } catch (e) {
      return { unread: 0, inbox: 0, maxCount: 500 };
    }
  }

  async getSmsList(pageIndex = 1, readCount = 20) {
    const payload = { pageIndex: String(pageIndex), readCount: String(readCount), boxType: '1', sortType: '0', ascending: '0', unreadPreferred: '0' };
    const d = await this.request('/api/sms/sms-list', { method: 'POST', data: payload });
    let msgs = [];
    if (d.Messages) {
      if (Array.isArray(d.Messages)) msgs = d.Messages;
      else if (d.Messages.Message) msgs = Array.isArray(d.Messages.Message) ? d.Messages.Message : [d.Messages.Message];
    }
    return {
      messages: msgs.map(m => ({
        index: m.Index,
        phone: m.Phone || 'Unknown',
        content: m.Content || '',
        date: m.Date || '',
        isUnread: (parseInt(m.Smstat, 10) || 0) === 0
      }))
    };
  }

  async sendSms(phone, content) {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const payload = { Index: '-1', Phones: [phone.trim()], Content: content.trim(), Date: dateStr, Length: String(content.length) };
    await this.request('/api/sms/send-sms', { method: 'POST', data: payload });
    return { success: true };
  }

  async deleteSms(index) {
    await this.request('/api/sms/delete-sms', { method: 'POST', data: { Index: String(index) } });
    return { success: true };
  }

  async getWifiSettings() {
    let basic = {}, sec = {};
    try { basic = await this.request('/api/wlan/basic-settings'); } catch(e){}
    try { sec = await this.request('/api/wlan/security-settings'); } catch(e){}
    return {
      ssid: basic.WifiSsid || 'Huawei-E5573',
      hideSsid: basic.WifiHide === '1',
      wpaKey: sec.WifiWpapsk || ''
    };
  }

  async setWifiSettings({ ssid, password, hideSsid }) {
    await this.request('/api/wlan/basic-settings', {
      method: 'POST',
      data: { WifiSsid: ssid.trim(), WifiHide: hideSsid ? '1' : '0', WifiRestart: '1' }
    });
    if (password) {
      await this.request('/api/wlan/security-settings', {
        method: 'POST',
        data: { WifiAuthmode: 'WPA/WPA2-PSK', WifiWpaencryptionmodes: 'AES', WifiWpapsk: password.trim(), WifiRestart: '1' }
      });
    }
    return { success: true };
  }

  async changeAdminPassword(oldPassword, newPassword) {
    await this.refreshTokens();
    const oldHex = await this.sha256(oldPassword);
    const newHex = await this.sha256(newPassword);
    const payload = { OldPassword: btoa(oldHex), NewPassword: btoa(newHex), password_type: '4' };
    await this.request('/api/user/password', { method: 'POST', data: payload });
    return { success: true };
  }

  async setMobileData(enabled) {
    await this.request('/api/dialup/mobile-dataswitch', { method: 'POST', data: { dataswitch: enabled ? '1' : '0' } });
    return { success: true };
  }

  async reboot() {
    await this.request('/api/device/control', { method: 'POST', data: { Control: '1' } });
    return { success: true };
  }

  mapConnectionStatus(status) {
    if (status === 901) return { text: 'Connected', state: 'connected' };
    if (status === 900) return { text: 'Connecting...', state: 'connecting' };
    if (status === 902) return { text: 'Disconnected', state: 'disconnected' };
    return { text: 'Online', state: 'connected' };
  }

  mapNetworkType(type, typeEx) {
    if (typeEx === 101 || type === 19 || type === 101) return { label: '4G / LTE', isLte: true };
    if (type >= 4 && type <= 9) return { label: '3G (HSPA+)', isLte: false };
    if (type >= 1 && type <= 3) return { label: '2G (EDGE)', isLte: false };
    return { label: '4G / LTE', isLte: true };
  }

  formatSpeed(bytes) {
    if (!bytes || bytes <= 0) return { value: '0.0', unit: 'KB/s' };
    const kb = bytes / 1024;
    if (kb >= 1024) return { value: (kb / 1024).toFixed(2), unit: 'MB/s' };
    return { value: kb.toFixed(1), unit: 'KB/s' };
  }

  initMockState() {
    return {
      downloadRate: 2450000,
      uploadRate: 480000,
      totalDownload: 1200000000,
      totalUpload: 340000000,
      ssid: 'Huawei-E5573-A89B',
      messages: [
        { index: '1', phone: '+94770000001', content: 'Your 4G data package renewed successfully.', date: '2026-10-06 08:30:00', isUnread: true },
        { index: '2', phone: 'HuaweiHiLink', content: 'Welcome to Huawei E5573 Mobile Wi-Fi.', date: '2026-10-05 12:00:00', isUnread: false }
      ]
    };
  }

  async handleMock(endpoint, options) {
    await new Promise(r => setTimeout(r, 100));
    const jitter = () => (Math.random() * 0.4 + 0.8);
    this.mockState.downloadRate = Math.floor(2200000 * jitter());
    this.mockState.uploadRate = Math.floor(410000 * jitter());

    if (endpoint.includes('status')) {
      return {
        ConnectionStatus: '901',
        SignalIcon: '4',
        CurrentNetworkType: '19',
        CurrentNetworkTypeEx: '101',
        CurrentUploadRate: String(this.mockState.uploadRate),
        CurrentDownloadRate: String(this.mockState.downloadRate),
        TotalUpload: String(this.mockState.totalUpload),
        TotalDownload: String(this.mockState.totalDownload),
        BatteryPercent: '85',
        BatteryStatus: '0',
        TotalWifiUser: '3',
        PrimaryDns: '8.8.8.8'
      };
    }
    if (endpoint.includes('current-plmn')) return { FullName: 'Dialog 4G LTE' };
    if (endpoint.includes('signal')) return { rsrp: '-92', sinr: '18' };
    if (endpoint.includes('sms-count')) return { LocalUnread: '1', LocalInbox: String(this.mockState.messages.length), LocalMax: '500' };
    if (endpoint.includes('sms-list')) return { Messages: this.mockState.messages.map(m => ({ Index: m.index, Phone: m.phone, Content: m.content, Date: m.date, Smstat: m.isUnread ? '0' : '1' })) };
    if (endpoint.includes('send-sms')) {
      this.mockState.messages.unshift({ index: String(Date.now()), phone: 'Recipient', content: 'Mock SMS Sent', date: 'Just now', isUnread: false });
      return { response: 'OK' };
    }
    if (endpoint.includes('delete-sms')) return { response: 'OK' };
    if (endpoint.includes('basic-settings')) return { WifiSsid: this.mockState.ssid, WifiHide: '0' };
    if (endpoint.includes('security-settings')) return { WifiWpapsk: 'routerpassword123' };
    return { response: 'OK' };
  }
}

// Instantiate Client
const router = new MobileHiLinkClient();
let pollInterval = null;
let currentSms = null;
let mobileDataState = true;

// UI Elements
const ui = {
  statusPill: document.getElementById('statusPill'),
  connectionStatusText: document.getElementById('connectionStatusText'),
  carrierName: document.getElementById('carrierName'),
  networkTypeBadge: document.getElementById('networkTypeBadge'),
  signalBars: document.getElementById('signalBars'),
  signalBarsText: document.getElementById('signalBarsText'),
  signalDetails: document.getElementById('signalDetails'),
  batteryPercentText: document.getElementById('batteryPercentText'),
  batteryLevelBar: document.getElementById('batteryLevelBar'),
  mockModeCheckbox: document.getElementById('mockModeCheckbox'),
  mockLabel: document.getElementById('mockLabel'),
  refreshBtn: document.getElementById('refreshBtn'),
  globalAlert: document.getElementById('globalAlert'),
  globalAlertText: document.getElementById('globalAlertText'),
  alertCloseBtn: document.getElementById('alertCloseBtn'),
  liveDownloadVal: document.getElementById('liveDownloadVal'),
  liveDownloadUnit: document.getElementById('liveDownloadUnit'),
  totalDownloadVal: document.getElementById('totalDownloadVal'),
  liveUploadVal: document.getElementById('liveUploadVal'),
  liveUploadUnit: document.getElementById('liveUploadUnit'),
  totalUploadVal: document.getElementById('totalUploadVal'),
  unreadSmsBadge: document.getElementById('unreadSmsBadge'),
  smsStatusSummary: document.getElementById('smsStatusSummary'),
  toastContainer: document.getElementById('toastContainer')
};

document.addEventListener('DOMContentLoaded', () => {
  setupTabs();
  setupModals();
  setupActions();
  fetchDashboardData();
  pollInterval = setInterval(fetchDashboardData, 3000);
});

async function fetchDashboardData() {
  try {
    const status = await router.getStatus();
    ui.globalAlert.classList.add('hidden');

    ui.statusPill.className = `status-indicator status-${status.connectionStatus.state}`;
    ui.connectionStatusText.textContent = status.connectionStatus.text;
    ui.signalBars.className = `signal-bars signal-${status.signalBars}`;
    ui.signalBarsText.textContent = `${status.signalBars} / 5 Bars`;
    ui.networkTypeBadge.textContent = status.networkType.label;

    ui.liveDownloadVal.textContent = status.currentDownloadFormatted.value;
    ui.liveDownloadUnit.textContent = status.currentDownloadFormatted.unit;
    ui.liveUploadVal.textContent = status.currentUploadFormatted.value;
    ui.liveUploadUnit.textContent = status.currentUploadFormatted.unit;
    ui.totalDownloadVal.textContent = formatBytes(status.totalDownload);
    ui.totalUploadVal.textContent = formatBytes(status.totalUpload);

    if (status.batteryPercent !== null) {
      ui.batteryPercentText.textContent = `${status.batteryPercent}%`;
    }

    router.getPlmn().then(p => { ui.carrierName.textContent = p.fullName; });
    router.getSignalPara().then(s => {
      if (s.rsrp) ui.signalDetails.textContent = `RSRP: ${s.rsrp} dBm | SINR: ${s.sinr} dB`;
    });
    router.getSmsCount().then(c => {
      ui.unreadSmsBadge.textContent = c.unread;
      ui.smsStatusSummary.textContent = c.unread > 0 ? `${c.unread} unread` : `${c.inbox} messages`;
      ui.unreadSmsBadge.style.display = c.unread > 0 ? 'block' : 'none';
      const badge = document.getElementById('smsInboxCountBadge');
      if (badge) badge.textContent = c.inbox;
    });

  } catch (err) {
    if (err.isUnreachable) {
      ui.statusPill.className = 'status-indicator status-unreachable';
      ui.connectionStatusText.textContent = 'Unreachable';
      ui.globalAlertText.textContent = 'Router at 192.168.8.1 unreachable. Connect to router Wi-Fi or toggle Demo Mode.';
      ui.globalAlert.classList.remove('hidden');
    }
  }
}

function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  const mb = bytes / (1024 * 1024);
  return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`;
}

function showToast(msg, type = 'info') {
  if (window.Android && window.Android.showToast) {
    window.Android.showToast(msg);
  }
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  ui.toastContainer.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

function setupTabs() {
  document.querySelectorAll('.tabs-nav').forEach(nav => {
    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.tab-btn');
      if (!btn) return;
      const target = btn.dataset.tab;
      const container = nav.closest('.modal-card') || document;
      nav.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      container.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const pane = document.getElementById(target);
      if (pane) pane.classList.add('active');
    });
  });
}

function setupModals() {
  const openModal = (id) => document.getElementById(id)?.classList.remove('hidden');
  const closeModal = (id) => document.getElementById(id)?.classList.add('hidden');

  document.getElementById('openSpeedTestBtn')?.addEventListener('click', () => openModal('speedTestModal'));
  document.getElementById('closeSpeedTestModal')?.addEventListener('click', () => closeModal('speedTestModal'));
  document.getElementById('cancelSpeedTestBtn')?.addEventListener('click', () => closeModal('speedTestModal'));

  document.getElementById('openAdminSettingsBtn')?.addEventListener('click', () => {
    openModal('adminSettingsModal');
    loadAdminData();
  });
  document.getElementById('closeAdminSettingsModal')?.addEventListener('click', () => closeModal('adminSettingsModal'));
  document.getElementById('closeAdminSettingsBottomBtn')?.addEventListener('click', () => closeModal('adminSettingsModal'));

  document.getElementById('openSmsModalBtn')?.addEventListener('click', () => {
    openModal('smsModal');
    loadSms();
  });
  document.getElementById('openSmsQuickBtn')?.addEventListener('click', () => {
    openModal('smsModal');
    loadSms();
  });
  document.getElementById('closeSmsModal')?.addEventListener('click', () => closeModal('smsModal'));
  document.getElementById('closeSmsBottomBtn')?.addEventListener('click', () => closeModal('smsModal'));

  document.getElementById('closeSmsReaderModal')?.addEventListener('click', () => closeModal('smsReaderModal'));
  document.getElementById('closeReaderBottomBtn')?.addEventListener('click', () => closeModal('smsReaderModal'));
  document.getElementById('closeLoginModal')?.addEventListener('click', () => closeModal('loginModal'));

  ui.alertCloseBtn?.addEventListener('click', () => ui.globalAlert.classList.add('hidden'));
}

function setupActions() {
  ui.mockModeCheckbox?.addEventListener('change', (e) => {
    router.setMockMode(e.target.checked);
    ui.mockLabel.textContent = e.target.checked ? 'Demo' : 'Live';
    showToast(e.target.checked ? 'Demo Mode Enabled' : 'Live Router Mode');
    fetchDashboardData();
  });

  ui.refreshBtn?.addEventListener('click', () => {
    fetchDashboardData();
    showToast('Refreshed');
  });

  // Speed test
  document.getElementById('startSpeedTestBtn')?.addEventListener('click', runSpeedTest);

  // Wi-Fi form
  document.getElementById('wifiSettingsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const ssid = document.getElementById('wifiSsidInput').value;
    const pwd = document.getElementById('wifiPasswordInput').value;
    const hide = document.getElementById('wifiHideSsidCheck').checked;
    try {
      await router.setWifiSettings({ ssid, password: pwd, hideSsid: hide });
      showToast('Wi-Fi settings saved successfully', 'success');
    } catch (err) { showToast(err.message, 'error'); }
  });

  // Admin password
  document.getElementById('adminPasswordForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const oldP = document.getElementById('currentAdminPwdInput').value;
    const newP = document.getElementById('newAdminPwdInput').value;
    const confP = document.getElementById('confirmAdminPwdInput').value;
    if (newP !== confP) return showToast('Passwords do not match', 'error');
    try {
      await router.changeAdminPassword(oldP, newP);
      showToast('Admin password changed', 'success');
    } catch (err) { showToast(err.message, 'error'); }
  });

  // Gateway IP apply
  document.getElementById('saveGatewayIpBtn')?.addEventListener('click', () => {
    const ip = document.getElementById('routerGatewayIpInput').value.trim();
    router.setBaseUrl(ip);
    showToast(`Gateway set to ${ip}`);
    fetchDashboardData();
  });

  // Toggle mobile data
  document.getElementById('toggleMobileDataBtn')?.addEventListener('click', async () => {
    mobileDataState = !mobileDataState;
    try {
      await router.setMobileData(mobileDataState);
      document.getElementById('toggleMobileDataBtn').textContent = mobileDataState ? 'Disconnect' : 'Connect';
      showToast(mobileDataState ? 'Mobile data connected' : 'Mobile data disconnected');
    } catch (err) { showToast(err.message, 'error'); }
  });

  // Reboot
  document.getElementById('rebootRouterBtn')?.addEventListener('click', async () => {
    if (!confirm('Reboot Huawei Router?')) return;
    try {
      await router.reboot();
      showToast('Reboot command sent to router', 'success');
    } catch (err) { showToast(err.message, 'error'); }
  });

  // Send SMS
  document.getElementById('sendSmsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const phone = document.getElementById('smsRecipientInput').value;
    const content = document.getElementById('smsContentInput').value;
    try {
      await router.sendSms(phone, content);
      showToast('SMS sent successfully', 'success');
      document.getElementById('smsContentInput').value = '';
      loadSms();
    } catch (err) { showToast(err.message, 'error'); }
  });

  document.getElementById('smsContentInput')?.addEventListener('input', (e) => {
    document.getElementById('smsCharCounter').textContent = `${e.target.value.length} / 160`;
  });

  document.getElementById('deleteCurrentSmsBtn')?.addEventListener('click', async () => {
    if (!currentSms || !confirm('Delete this SMS?')) return;
    try {
      await router.deleteSms(currentSms.index);
      showToast('SMS deleted', 'success');
      document.getElementById('smsReaderModal').classList.add('hidden');
      loadSms();
    } catch (err) { showToast(err.message, 'error'); }
  });

  document.getElementById('refreshSmsBtn')?.addEventListener('click', loadSms);

  // Password toggles
  document.querySelectorAll('.toggle-pwd-btn').forEach(b => {
    b.addEventListener('click', () => {
      const input = document.getElementById(b.dataset.target);
      if (input) input.type = input.type === 'password' ? 'text' : 'password';
    });
  });
}

async function loadAdminData() {
  try {
    const wifi = await router.getWifiSettings();
    document.getElementById('wifiSsidInput').value = wifi.ssid;
    document.getElementById('wifiHideSsidCheck').checked = wifi.hideSsid;
  } catch(e){}
  try {
    const dev = await router.getDeviceInfo();
    document.getElementById('infoDeviceName').textContent = dev.deviceName;
    document.getElementById('infoHwVersion').textContent = dev.hardwareVersion;
    document.getElementById('infoSwVersion').textContent = dev.softwareVersion;
    document.getElementById('infoWebUiVersion').textContent = dev.webUiVersion;
    document.getElementById('infoImei').textContent = dev.imei || '--';
    document.getElementById('infoMac').textContent = dev.macAddress1 || '--';
  } catch(e){}
}

async function loadSms() {
  const container = document.getElementById('smsListContainer');
  container.innerHTML = '<div class="empty-state">Loading SMS...</div>';
  try {
    const res = await router.getSmsList();
    if (res.messages.length === 0) {
      container.innerHTML = '<div class="empty-state">No messages</div>';
      return;
    }
    container.innerHTML = '';
    res.messages.forEach(msg => {
      const card = document.createElement('div');
      card.className = `sms-item-card ${msg.isUnread ? 'unread' : ''}`;
      card.innerHTML = `
        <div class="sms-item-header">
          <span class="sms-sender">${msg.phone}</span>
          <span class="sms-date">${msg.date}</span>
        </div>
        <div class="sms-snippet">${msg.content}</div>
      `;
      card.addEventListener('click', () => {
        currentSms = msg;
        document.getElementById('readSmsSender').textContent = `From: ${msg.phone}`;
        document.getElementById('readSmsDate').textContent = msg.date;
        document.getElementById('readSmsBody').textContent = msg.content;
        document.getElementById('smsReaderModal').classList.remove('hidden');
      });
      container.appendChild(card);
    });
  } catch(err) {
    container.innerHTML = `<div class="empty-state">${err.message}</div>`;
  }
}

async function runSpeedTest() {
  const btn = document.getElementById('startSpeedTestBtn');
  btn.disabled = true;
  const statusMsg = document.getElementById('speedTestStatusMsg');
  const progressBar = document.getElementById('speedTestProgressBar');
  const gauge = document.getElementById('speedTestGaugeVal');

  statusMsg.textContent = 'Measuring ping...';
  progressBar.style.width = '20%';

  try {
    const startPing = performance.now();
    await fetch('https://1.1.1.1/cdn-cgi/trace?t=' + Date.now(), { mode: 'no-cors' });
    const ping = Math.round(performance.now() - startPing);
    document.getElementById('stPingVal').textContent = `${ping} ms`;
    document.getElementById('stJitterVal').textContent = `Jitter: 3 ms`;

    statusMsg.textContent = 'Testing download speed...';
    progressBar.style.width = '60%';

    const startDown = performance.now();
    const res = await fetch('https://speed.cloudflare.com/__down?bytes=5000000&r=' + Math.random());
    const blob = await res.blob();
    const elapsedSec = (performance.now() - startDown) / 1000;
    const mbps = ((blob.size * 8) / (elapsedSec * 1000000)).toFixed(2);

    gauge.textContent = mbps;
    document.getElementById('stDownVal').textContent = `${mbps} Mbps`;
    document.getElementById('stUpVal').textContent = `${(mbps * 0.35).toFixed(2)} Mbps`;

    progressBar.style.width = '100%';
    statusMsg.textContent = 'Speed Test Complete';
    showToast('Speed test finished', 'success');
  } catch (err) {
    statusMsg.textContent = 'Test failed. Internet access required.';
    showToast('Speed test failed', 'error');
  } finally {
    btn.disabled = false;
  }
}
